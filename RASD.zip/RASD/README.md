# SE2-Travlendar-Bolshakova-Campagnoli-Lagni
The mandatory project of Software engineering 2 course in Politecnico di Milano, a.y. 2017-18

Bolshakova Liubov, Campagnoli Chiara,Lagni Luca 
