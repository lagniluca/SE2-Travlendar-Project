package travlendarplusserversidecode.model.constants;

/**
 *
 * Enum that represents the possible euro class type for a veichle
 * @author Lagni Luca
 * @date 21/11/2017
 * @version 1.0
 */
public enum EuroClassType {
    
    /*
     *Unspecified is used in case that the user or vendors doesn't provide infos
     *about the class type of a veichle, so we pot ourself in the worst case
    */
    UNSPECIFIED(new Integer(Integer.MIN_VALUE)),
    EURO_0(new Integer(0)),
    EURO_1(new Integer(1)),
    EURO_2(new Integer(2)),
    EURO_3(new Integer(3)),
    EURO_4(new Integer(4)),
    EURO_5(new Integer(5)),
    EURO_6(new Integer(6)),
    /*PT is specified because, even if the euro class is low ,
     *they can be considered the most echological solution in case
     *of veichles , so we put it in the best case
    */
    PUBLIC_TRANSPORT(new Integer(Integer.MAX_VALUE));
    
    
    private Integer euroClass;
    
    EuroClassType(final Integer euroClass){ this.setEuroClass(euroClass); }
    
    private void setEuroClass(final Integer euroClass){ this.euroClass = euroClass; }
    public Integer getEuroClass(){ return this.euroClass; }
}
