package travlendarplusserversidecode.model.applicationabstractclasstypes;
/**
 *
 * @author Lagni Luca
 */
public class MeanOfTransport {
   private Boolean available ;
   private Boolean allowed ;
   private Boolean forSpecialPourpose;
   private Boolean forDisablePerson;
   
   public MeanOfTransport(final Boolean available,final Boolean allowed,final Boolean forSpecialPurpose,final Boolean forDisablePerson){
       this.setAvailable(available);
       this.setAllowed(allowed);
       this.setForSpecialPourpose(forSpecialPurpose);
       this.setForDisablePerson(forDisablePerson);
   }
   
   private void setAvailable(final Boolean available){ this.available = available; }
   private void setAllowed(final Boolean allowed){ this.allowed = allowed; }
   private void setForSpecialPourpose(final Boolean forSpecialPurpose){ this.forSpecialPourpose = forSpecialPurpose; }
   private void setForDisablePerson(final Boolean forDisablePerson){ this.forDisablePerson = forDisablePerson; }

   public Boolean isAvailable(){ return this.available; }
   public Boolean isAllowed(){ return this.allowed; }
   public Boolean isForSpecialPurpose(){ return this.forSpecialPourpose; }
   public Boolean isForDisablePerson(){ return this.forDisablePerson; }
}
