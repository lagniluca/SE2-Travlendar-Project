package travlendarplusserversidecode.model.applicationclasstypes;

import travlendarplusserversidecode.model.applicationabstractclasstypes.User;

/**
 *
 * Class that represent a registred user of our application
 * 
 * @author Lagni Luca
 * @date 21/11/2017
 * @version 1.0
 */
public class Client extends User {
    
}
