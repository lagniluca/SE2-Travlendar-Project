package travlendarplusserversidecode.model.constants;

/**
 * this enum is used to strictly define if a coordinate subclass
 * is a latitude or a longitude
 * @author Lagni Luca
 */
public enum CoordinateFormatType {
    
    LATITUDE("LATITUDE"),
    LONGITUDE("LONGITUDE");
    
    private String coordinateType;
    
    CoordinateFormatType(final String coordinateType){ this.setCoordinateType(coordinateType); }

    private void setCoordinateType(final String coordinateType){ this.coordinateType = coordinateType; }
    public String getCoordinateType(){ return this.coordinateType; }
}
