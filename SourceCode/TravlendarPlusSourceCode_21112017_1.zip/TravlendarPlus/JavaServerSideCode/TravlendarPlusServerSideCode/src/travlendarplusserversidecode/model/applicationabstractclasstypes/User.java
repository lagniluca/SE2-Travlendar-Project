package travlendarplusserversidecode.model.applicationabstractclasstypes;

import java.util.Date;

/**
 *
 * Class that represent a user of Travlendar+ application
 * @author Lagni Luca
 * @date 21/11/2017
 * @version 1.0
 */
public abstract class User {
    private Integer id;
    private Date dateOfBirth;
    
}
