package travlendarplusserversidecode.model.applicationclasstypes;

import travlendarplusserversidecode.model.applicationabstractclasstypes.User;

/**
 * Class that is used to represent an unregistred client
 * @author Lagni Luca
 * @date 21/11/2017
 * @verison 1.0
 */
public class Visitor extends User {
    
}
