package travlendarplusserversidecode.model.applicationabstractclasstypes;

import travlendarplusserversidecode.model.constants.CoordinateFormatType;

/**
 * This is a wrapper class for the CoordinateFormat specifically 
 * intended for Latitude
 * 
 * @author Lagni Luca
 * @date 21/11/2017
 * @version 1.0
 */

public class Latitude extends CoordinateFormat{
    
   public Latitude(final Integer degrees,final Integer minutes,final Integer seconds){
     super(CoordinateFormatType.LATITUDE, degrees, minutes, seconds);  
   } 
}
