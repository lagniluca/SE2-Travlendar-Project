/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationclasstypes;

import java.util.Date;
import travlendarplusserversidecode.model.applicationabstractclasstypes.Notification;
import travlendarplusserversidecode.model.applicationabstractclasstypes.NotificationObserver;
import travlendarplusserversidecode.model.interfaces.TripNotificationObserver;
import travlendarplusserversidecode.model.interfaces.TripNotificationSubject;

/**
 *
 * @author Chiara Campagnoli
 */
public class Trip implements TripNotificationSubject, NotificationObserver {
    private Date timeInterval;
    private Boolean riskZone;
    private Integer ID;
    private Navigator navigator;
    private Break b;
    private Coordinate startingPoint;
    private Coordinate endingPoint;
    
    public Trip(final Date timeInterval, final Boolean riskZone, final Integer ID, final Navigator navigator, final Break b, Coordinate start, Coordinate end) {
    this.setInterval(timeInterval);
    this.setRiskZone(riskZone);
    this.setID(ID);
    this.setNavigator(navigator);
    this.setBreak(b);
    this.setStart(start);
    this.setEnd(end);
    }
    
    private void setInterval(final Date timeInterval) {this.timeInterval = timeInterval;}
    private void setRiskZone(final Boolean riskZone) {this.riskZone = riskZone;}
    private void setID(final Integer ID) {this.ID = ID;}
    private void setNavigator(final Navigator navigator) {this.navigator = navigator;}
    private void setBreak(final Break b) {this.b = b;}
    private void setStart(Coordinate start) {this.startingPoint = start;}
    private void setEnd (Coordinate end) {this.endingPoint = end;}
    
    public Date getTimeInterval() {return this.timeInterval;}
    public Break getBreak() {return this.b;}
    public Coordinate getStartingPoint() {return this.startingPoint;}
    public Coordinate getEndingPoint() {return this.endingPoint;}
    
    //public LinkedHashSet<PathRestriction> getPathRestrictions

    @Override
    public TripNotificationObserver register(TripNotificationObserver o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public TripNotificationObserver unregister(TripNotificationObserver o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean notifyObservers() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Notification update(Notification n) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
