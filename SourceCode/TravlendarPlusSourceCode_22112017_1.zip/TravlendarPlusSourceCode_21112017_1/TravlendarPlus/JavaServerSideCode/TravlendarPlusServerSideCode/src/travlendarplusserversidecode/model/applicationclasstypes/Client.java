package travlendarplusserversidecode.model.applicationclasstypes;

import java.util.ArrayList;
import java.util.Date;
import travlendarplusserversidecode.model.applicationabstractclasstypes.MeanOfTransport;
import travlendarplusserversidecode.model.applicationabstractclasstypes.Notification;
import travlendarplusserversidecode.model.applicationabstractclasstypes.User;

/**
 *
 * Class that represent a registred user of our application
 * 
 * @author Lagni Luca
 * @date 21/11/2017
 * @version 1.0
 */
public class Client extends User {
    private String eMail;
    private Settings preferredSettings;
    private String userName;
    private ArrayList<MeanOfTransport> personalMOT;
    private ArrayList<Meeting> scheduledMeetings;

    public Client(Integer ID, Date date, ArrayList<Meeting> meetings) {
        super(ID, date, meetings);
    }
    
    public Meeting addScheduledMeeting(Meeting m) {
    this.scheduledMeetings.add(m);
    return m;}
    
    public Meeting removeScheduledMeeting(Meeting m) {
    this.scheduledMeetings.remove(m);
    return m;}
    
    public MeanOfTransport addPersonalMOT(MeanOfTransport mot) {
    this.personalMOT.add(mot);
    return mot;}
    
    public MeanOfTransport removePersonalMOT(MeanOfTransport mot) {
    this.personalMOT.remove(mot);
    return mot;}
    

    @Override
    public Notification update(Notification n) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
