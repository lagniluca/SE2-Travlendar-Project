/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.interfaces;

import java.util.Date;
import travlendarplusserversidecode.model.applicationclasstypes.Coordinate;

/**
 *
 * @author Chiara Campagnoli
 */
public interface UserDevice {
    public String getUserOS();
    public Coordinate getPosition();
    public Boolean sendNotification();
    public Date getTimeStamp();
}
