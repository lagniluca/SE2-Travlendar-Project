/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationclasstypes;

import java.util.HashMap;
import travlendarplusserversidecode.model.applicationabstractclasstypes.MeanOfTransport;

/**
 *
 * @author Chiara Campagnoli
 */
public class ExternalMeanOfTransportCompany extends ExternalCompany {
    private String bookingURL;
    private Boolean publicCompany;
    private MeanOfTransport MOT;

    public ExternalMeanOfTransportCompany(Integer ID, String brandName, String supportURL, HashMap<String, String> OtheURLs) {
        super(ID, brandName, supportURL, OtheURLs);
    }
    
    
    
    private void setBookingURL(final String bookURL) {this.bookingURL = bookingURL;}
    private void setPublic(final Boolean publicCompany) {this.publicCompany = publicCompany;}
    private void setMOT(final MeanOfTransport MOT) {this.MOT = MOT;}
    
    //public Boolean redirectToBookingUrl()
    
}
