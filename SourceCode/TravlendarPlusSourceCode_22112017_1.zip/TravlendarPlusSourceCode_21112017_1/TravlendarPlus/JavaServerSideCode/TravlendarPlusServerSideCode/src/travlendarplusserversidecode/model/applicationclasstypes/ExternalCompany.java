/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationclasstypes;

import java.util.HashMap;
import travlendarplusserversidecode.model.applicationabstractclasstypes.Notification;

/**
 *
 * @author Chiara Campagnoli
 */
public class ExternalCompany {
    private Integer ID;
    private String brandName;
    private String supportURL;
    private HashMap<String,String> OtherURLs;
    
    public ExternalCompany (final Integer ID, final String brandName, final String supportURL, final HashMap<String,String> OtheURLs) {
    this.setID(ID);
    this.setBrandName(brandName);
    this.setSupportURL(supportURL);
    this.OtherURLs = OtherURLs;
    }
    
    private void setID(final Integer ID){ this.ID = ID; }
    private void setBrandName(final String brandName){ this.brandName = brandName; }
    private void setSupportURL(final String supportURL){ this.supportURL = supportURL; }
    
    public String getURL() {return this.supportURL;}
    //public Notification createNotification()
    //public Notification deleteNotification()
}
