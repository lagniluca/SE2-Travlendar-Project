package travlendarplusserversidecode.model.usersmanagement;

/**
 * Class that contains some tools that can be useful for the server side
 * user management
 * 
 * @author Lagni Luca
 * @date 21/11/2017
 * @version 1.0
 */
public class UserUtility {
    private static Integer currentUserID = null;
    
    /**
     * Method used to generate users' ID 
     * This method doesn't retrive ID from the database because Users are 
     * anonymous , they aren't (obviously) stored in the database.
     * @return 
     */
    public static Integer generateUserID(){
       if(currentUserID == null) currentUserID = 0;
       else currentUserID++;
       
       return currentUserID;
    }
    
}
