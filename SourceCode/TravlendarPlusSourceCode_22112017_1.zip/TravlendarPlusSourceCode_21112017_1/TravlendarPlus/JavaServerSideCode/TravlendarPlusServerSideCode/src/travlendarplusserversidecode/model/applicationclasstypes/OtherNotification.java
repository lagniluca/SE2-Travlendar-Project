/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationclasstypes;

import travlendarplusserversidecode.model.applicationabstractclasstypes.Notification;

/**
 *
 * @author Chiara Campagnoli
 */
public class OtherNotification extends Notification {
    
    public OtherNotification(Integer ID, String title, String description, ExternalCompany company) {
        super(ID, title, description, company);
    }
    
}
