/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationclasstypes;

import java.util.ArrayList;
import java.util.Date;
import travlendarplusserversidecode.model.applicationabstractclasstypes.Notification;
import travlendarplusserversidecode.model.applicationabstractclasstypes.User;
import travlendarplusserversidecode.model.interfaces.TripNotificationObserver;

/**
 *
 * @author Chiara Campagnoli
 */
public class Meeting implements TripNotificationObserver {
    private Integer ID;
    private Date startingTime;
    private Date endingTime;
    private Integer priority;
    private ArrayList<Trip> trips;
    private User user;
    
    public Meeting(final Integer ID, final Date start, final Date end, final Integer priority, ArrayList<Trip> trips, final User user) {
    this.setID(ID);
    this.setStartingTime(start);
    this.setEndingTime(end);
    this.setPriority(priority);
    this.setTrips(trips);
    this.setUser(user);
    }
    
    private void setID(final Integer ID) {this.ID = ID;}
    private void setStartingTime(final Date startingTime) {this.startingTime = startingTime;}
    private void setEndingTime(final Date endingTime) {this.endingTime = endingTime;}
    private void setPriority(final Integer priority) {this.priority = priority;}
    private void setTrips(ArrayList<Trip> trips) {this.trips = trips;}
    private void setUser(final User user) {this.user = user;}
    
    public Date getStartingTime() {return this.startingTime;}
    public Date getEndingTime() {return this.endingTime;}
    public Integer getPriority() {return this.priority;}
    public ArrayList<Trip> getTrips() {return this.trips;}
    public Trip getTrip(Integer position) {return this.trips.get(position);}
    
    public Trip addTrip(Trip t) {trips.add(t);
    return t;
    }
    
    public Trip deleteTrip(Trip t) {
    trips.remove(t);
    return t;}
    
    public Trip deleteTripAt(Integer position) {
        Trip t = trips.get(position);
    this.deleteTrip(t);
    return t;}
    
    //public String impossibleStringNotification()

    @Override
    public Notification update(Notification n) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
