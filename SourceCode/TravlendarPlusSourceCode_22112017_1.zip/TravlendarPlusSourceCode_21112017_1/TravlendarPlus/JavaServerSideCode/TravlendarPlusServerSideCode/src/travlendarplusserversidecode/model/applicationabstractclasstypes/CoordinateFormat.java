package travlendarplusserversidecode.model.applicationabstractclasstypes;

import travlendarplusserversidecode.model.constants.CoordinateFormatType;

/**
 *
 * Class used to define the format of latitude and longitude
 * @author Lagni Luca
 * @date 21/11/2017
 * @version 1.0
 */
public class CoordinateFormat {
    private CoordinateFormatType coordinateType;
    private Integer degrees;
    private Integer minutes;
    private Integer seconds;
    
    public CoordinateFormat(final CoordinateFormatType coordinateType, final Integer degrees,final Integer minutes,final Integer seconds){
       this.setCoordinateType(coordinateType);
       this.setDegrees(degrees);
       this.setMinutes(minutes);
       this.setSeconds(seconds);
    }
    
    private void setDegrees(final Integer degrees){ 
        this.degrees = degrees; 
    }
    private void setMinutes(final Integer minutes){ this.minutes = minutes; }
    private void setSeconds(final Integer seconds){ this.seconds = seconds; }
    private void setCoordinateType(final CoordinateFormatType coordinateType){
        this.coordinateType = coordinateType; 
    }
    
    public void updateCoordinate(final CoordinateFormat coordinate){
        this.setDegrees(coordinate.getDegrees());
        this.setMinutes(coordinate.getMinutes());
        this.setSeconds(coordinate.getSeconds());
    }
    
    public Integer getDegrees(){ return this.degrees; }
    public Integer getMinutes(){ return this.minutes; }
    public Integer getSeconds(){ return this.seconds; }
    public CoordinateFormatType getCoordinateFormatType(){ return this.coordinateType; }
    
    /**
     * This method is like the toString() but it it intended to be used when the coordinate is not 
     * showed by it's own
     * @return 
     */
    public String dependentToString(){
        String s = "";
 
        s += this.getCoordinateFormatType().getCoordinateType() + " : " ;
        s += " Value: " + this.getDegrees() + "° " + this.getMinutes() + "' " + this.getSeconds() + "'' ";
        
        return s;
    }
    
    public Boolean compareTo(final CoordinateFormat coordinate){
        if(this.getCoordinateFormatType() != coordinate.getCoordinateFormatType())return new Boolean(false);
        if(this.getDegrees() != coordinate.getDegrees()) return new Boolean(false);
        if(this.getMinutes() != coordinate.getMinutes()) return new Boolean(false);
        if(this.getSeconds() != coordinate.getSeconds()) return new Boolean(false);
        
        return new Boolean(true);
    }
    
    @Override
    public String toString(){
        String s = "\n=========={Single Coordinate}==========\n";
        
        s += "\nCoordinate type: " + this.getCoordinateFormatType().getCoordinateType();
        s += "\nValue: " + this.getDegrees() + "° " + this.getMinutes() + "' " + this.getSeconds() + "'' ";
        s += "\nDegrees: " + this.getDegrees() ;
        s += "\nMinutes: " + this.getMinutes();
        s += "\nSeconds: " + this.getSeconds();
        
        return s;
    }
}
