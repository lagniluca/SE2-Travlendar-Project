/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationclasstypes;

/**
 *
 * @author Chiara Campagnoli
 */
public class Technician {
    private Integer ID;
    private Integer companyMatrix;
    private String firstName;
    private String lastName;
    private Boolean available;
    private String email;
    private String phone;
    
    public Technician(final Integer ID, final Integer companyMatrix, final String firstName, final String lastName, final Boolean available, final String email, final String phone) {
    this.setID(ID);
    this.setCompanyMatrix(companyMatrix);
    this.setFirstName(firstName);
    this.setLastName(lastName);
    this.setAvailable(available);
    this.setEmal(email);
    this.setPhoneNumber(phone);}
    
    private void setID(final Integer ID) {this.ID = ID;}
    private void setCompanyMatrix(final Integer mat) {this.companyMatrix = mat;}
    private void setFirstName(final String name) {this.firstName = name;}
    private void setLastName(final String name) {this.lastName = name;}
    private void setAvailable(final Boolean available) {this.available = available;}
    private void setEmal(final String email) {this.email = email;}
    private void setPhoneNumber (final String phone) {this.phone = phone;}
}
