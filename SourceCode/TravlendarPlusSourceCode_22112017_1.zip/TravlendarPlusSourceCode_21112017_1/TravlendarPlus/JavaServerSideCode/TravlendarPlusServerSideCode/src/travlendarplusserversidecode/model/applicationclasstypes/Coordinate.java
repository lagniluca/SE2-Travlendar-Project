package travlendarplusserversidecode.model.applicationclasstypes;

import travlendarplusserversidecode.model.applicationabstractclasstypes.Latitude;
import travlendarplusserversidecode.model.applicationabstractclasstypes.Longitude;

/**
 *
 * @author Lagni Luca
 * @date 21/11/2017
 * @version 1.0
 */
public class Coordinate {
    private Latitude latitude;
    private Longitude longitude;
    
    public Coordinate(final Latitude latitude,final Longitude longitude){
        this.setLatitude(latitude);
        this.setLongitude(longitude);
    }
    
    private void setLatitude(final Latitude latitude){ this.latitude = latitude; }
    
    private void setLongitude(final Longitude longitude){ this.longitude = longitude; }
    
    public Latitude getLatitude() {return this.latitude;}
    public Longitude getLongitude() {return this.longitude;}
}
