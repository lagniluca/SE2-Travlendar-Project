/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationclasstypes;

import travlendarplusserversidecode.model.applicationabstractclasstypes.NonAutonomousMeanOfTransport;
import travlendarplusserversidecode.model.constants.EuroClassType;

/**
 *
 * @author Chiara Campagnoli
 */
public class Boat extends NonAutonomousMeanOfTransport {
    
    public Boat(Boolean available, Boolean allowed, Boolean forSpecialPurpose, Boolean forDisablePerson, EuroClassType envClass) {
        super(available, allowed, forSpecialPurpose, forDisablePerson, envClass);
    }
    
    
    
}
