/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationclasstypes;

import java.util.ArrayList;

/**
 *
 * @author Chiara Campagnoli
 */
public class TechnicalProblem {
    private Integer ID;
    private String title;
    private String description;
    private ArrayList<Technician> technicians;
}
