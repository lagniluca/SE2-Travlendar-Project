/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationclasstypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import travlendarplusserversidecode.model.applicationabstractclasstypes.MeanOfTransport;
import travlendarplusserversidecode.model.applicationabstractclasstypes.Notification;
import travlendarplusserversidecode.model.applicationabstractclasstypes.NotificationObserver;

/**
 *
 * @author Chiara Campagnoli
 */
public class Navigator implements NotificationObserver {
    private HashSet<MeanOfTransport> availableMOT;
    private ArrayList<MeanOfTransport> allowedMOT;
    private HashMap<MeanOfTransport, Boolean> suggestedMOT;
    private MeanOfTransport selectedMOT;
    
    public Navigator(HashSet<MeanOfTransport> available, ArrayList<MeanOfTransport> allowedMOT, HashMap<MeanOfTransport, Boolean> suggested, MeanOfTransport selected) {
    this.setAvailableMOT(available);
    this.setAllowedMOT(allowedMOT);
    this.setSuggestedMOT(suggested);
    this.setSelectedMOT(selected);}
    
    
    
    private void setAvailableMOT(HashSet availableMOT) {this.availableMOT = availableMOT;}
    private void setAllowedMOT(ArrayList allowedMOT) {this.allowedMOT = allowedMOT;}
    private void setSuggestedMOT(HashMap suggestedMOT) {this.suggestedMOT = suggestedMOT;}
    private void setSelectedMOT(MeanOfTransport selectedMOT) {this.selectedMOT = selectedMOT;}
    
    //public Date changeMOT(Date timeInterval)
    
    //public MeanOfTransport suggestMOT(Date timeInterval)
    
    //public Boolean flush()

    @Override
    public Notification update(Notification n) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
