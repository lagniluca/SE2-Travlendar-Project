package travlendarplusserversidecode.model.applicationabstractclasstypes;

import travlendarplusserversidecode.model.constants.EuroClassType;

/**
 *
 * @author Lagni Luca
 */
public class MeanOfTransport implements NotificationObserver {
   private Integer ID;
   private Boolean available ;
   private Boolean allowed ;
   private Boolean forSpecialPourpose;
   private Boolean forDisablePerson;
   private EuroClassType envClass;
   
   public MeanOfTransport(final Boolean available,final Boolean allowed,final Boolean forSpecialPurpose,final Boolean forDisablePerson, final EuroClassType envClass){
       this.setAvailable(available);
       this.setAllowed(allowed);
       this.setForSpecialPourpose(forSpecialPurpose);
       this.setForDisablePerson(forDisablePerson);
       this.setEnvClass(envClass);
   }
   
   private void setAvailable(final Boolean available){ this.available = available; }
   private void setAllowed(final Boolean allowed){ this.allowed = allowed; }
   private void setForSpecialPourpose(final Boolean forSpecialPurpose){ this.forSpecialPourpose = forSpecialPurpose; }
   private void setForDisablePerson(final Boolean forDisablePerson){ this.forDisablePerson = forDisablePerson; }
   private void setEnvClass(final EuroClassType envClass) {this.envClass = envClass;}

   public Boolean isAvailable(){ return this.available; }
   public Boolean isAllowed(){ return this.allowed; }
   public Boolean isForSpecialPurpose(){ return this.forSpecialPourpose; }
   public Boolean isForDisablePerson(){ return this.forDisablePerson; }
   public EuroClassType getEnvironmentClass() {return this.envClass;}
   
   //public Coordinate getPosition()

    @Override
    public Notification update(Notification n) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
