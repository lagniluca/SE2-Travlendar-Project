/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationabstractclasstypes;

import travlendarplusserversidecode.model.constants.EuroClassType;

/**
 *
 * @author Chiara Campagnoli
 */
public abstract class NonAutonomousMeanOfTransport extends MeanOfTransport {
    
    public NonAutonomousMeanOfTransport(Boolean available, Boolean allowed, Boolean forSpecialPurpose, Boolean forDisablePerson, EuroClassType envClass) {
        super(available, allowed, forSpecialPurpose, forDisablePerson, envClass);
    }
    
    
    
}
