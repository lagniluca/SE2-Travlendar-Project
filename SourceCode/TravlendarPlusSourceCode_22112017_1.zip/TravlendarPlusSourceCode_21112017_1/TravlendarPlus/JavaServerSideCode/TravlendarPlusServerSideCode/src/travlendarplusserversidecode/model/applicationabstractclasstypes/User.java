package travlendarplusserversidecode.model.applicationabstractclasstypes;

import java.util.ArrayList;
import java.util.Date;
import travlendarplusserversidecode.model.applicationclasstypes.Meeting;
import travlendarplusserversidecode.model.applicationclasstypes.UserDeviceFactory;
import travlendarplusserversidecode.model.interfaces.TripNotificationObserver;

/**
 *
 * Class that represent a user of Travlendar+ application
 * @author Lagni Luca
 * @date 21/11/2017
 * @version 1.0
 */
public abstract class User implements TripNotificationObserver {
    private Integer ID;
    private Date dateOfBirth;
    private ArrayList<Meeting> meetings;
    private UserDeviceFactory factory;
    
    public User(Integer ID, Date date, ArrayList<Meeting> meetings) {
    this.setID(ID);
    this.setDateOfBirth(date);
    this.setMeetings(meetings);}
    
    private void setID(Integer ID) {this.ID = ID;}
    private void setDateOfBirth(Date date) {this.dateOfBirth = date;}
    private void setMeetings(ArrayList<Meeting> meetings) {this.meetings = meetings;}
    
    //public Meeting createMeeting()
    //public Meeting deleteMeeting()
    
}
