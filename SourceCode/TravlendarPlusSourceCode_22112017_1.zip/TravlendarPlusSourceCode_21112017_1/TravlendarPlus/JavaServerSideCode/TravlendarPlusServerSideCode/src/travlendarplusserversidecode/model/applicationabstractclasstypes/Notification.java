/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationabstractclasstypes;

import travlendarplusserversidecode.model.applicationclasstypes.ExternalCompany;

/**
 *
 * @author Chiara Campagnoli
 */
public class Notification {
    private Integer ID;
    private String title;
    private String description;
    private ExternalCompany company;
    
    public Notification (final Integer ID, final String title, final String description, final ExternalCompany company) {
    this.setID(ID);
    this.setTitle(title);
    this.setDescription(description);
    this.setCompany(company);
    }
    
    private void setID(final Integer ID) {this.ID = ID;}
    private void setTitle(final String title) {this.title = title;}
    private void setDescription (final String description) {this.description = description;}
    private void setCompany(final ExternalCompany company) {this.company = company;}
}
