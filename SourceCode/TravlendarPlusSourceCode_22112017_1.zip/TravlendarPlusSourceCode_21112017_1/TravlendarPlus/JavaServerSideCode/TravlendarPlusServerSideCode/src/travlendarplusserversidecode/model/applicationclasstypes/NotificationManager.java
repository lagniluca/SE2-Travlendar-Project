/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationclasstypes;

import java.util.ArrayList;
import travlendarplusserversidecode.model.applicationabstractclasstypes.Notification;

/**
 *
 * @author Chiara Campagnoli
 */
public class NotificationManager {
    private static NotificationManager instance;
    private ArrayList<Notification> notifications;
           
    
    private NotificationManager() {
    }
    
    public static NotificationManager instance() {
        if (instance == null) instance = new NotificationManager();
        return instance;
    }
    
    public Notification addNotification(Notification n) {
    this.notifications.add(n);
    return n;}
    
    //public Notification removeNotification(Notification n, ExternalCompany ec)
    
   //public Notification removeNotificationAt(Integer position, ExternalCompany ec)
    
   
}
