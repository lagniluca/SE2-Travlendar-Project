package travlendarplusserversidecode.model.applicationclasstypes;

/**
 *
 * Class that contains shared objects of our application
 * 
 * @author Lagni Luca
 * @date 21/11/2017
 * @version 1.0
 */
public class SystemShared {
    private static SystemShared instance = null ;
    
    private SystemShared(){}
    
    public static SystemShared getInstance(){
        if(instance == null) instance = new SystemShared();
        
        return instance;
    }
}
