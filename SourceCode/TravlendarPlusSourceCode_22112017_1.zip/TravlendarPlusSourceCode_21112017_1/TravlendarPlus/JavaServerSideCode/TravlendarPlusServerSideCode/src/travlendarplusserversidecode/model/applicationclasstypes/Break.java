/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationclasstypes;

import java.util.Date;

/**
 *
 * @author Chiara Campagnoli
 */
class Break {
    private Boolean active;
    private Date startingTime;
    private Boolean enableAlarm;
    private Date endingTime;
    
    public Break(final Boolean active, final Date startingTime, final Boolean enableAlarm, final Date endingTime) {
    this.setActive(active);
    this.setStartingTime(startingTime);
    this.setAlarm(enableAlarm);
    this.setEndingTime(endingTime);
    }
    
    private void setActive(final Boolean active) {this.active = active;}
    private void setStartingTime(final Date startingTime) {this.startingTime = startingTime;}
    private void setAlarm(final Boolean enableAlarm) {this.enableAlarm = enableAlarm;}
    private void setEndingTime(final Date endingTime) {this.endingTime = endingTime;}
    
    public Date getStartingTime() {return this.startingTime;}
    public Date getEndingTime() {return this.endingTime;}
    public Boolean isAlarmEnabled() {return this.enableAlarm;}
    public Date getTimeInterval() {
    if (this.startingTime.before(this.endingTime)) {
        Date date = new Date();
        date.setTime(endingTime.getTime() - startingTime.getTime());
        return date;
    }
    }
   
}
