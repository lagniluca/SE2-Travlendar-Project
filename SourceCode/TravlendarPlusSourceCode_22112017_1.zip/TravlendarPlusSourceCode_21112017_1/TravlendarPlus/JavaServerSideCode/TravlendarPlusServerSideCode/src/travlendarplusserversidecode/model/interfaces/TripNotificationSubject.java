/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.interfaces;

/**
 *
 * @author Chiara Campagnoli
 */
public interface TripNotificationSubject {
    public TripNotificationObserver register(TripNotificationObserver o);
    public TripNotificationObserver unregister(TripNotificationObserver o);
    public Boolean notifyObservers();

}
