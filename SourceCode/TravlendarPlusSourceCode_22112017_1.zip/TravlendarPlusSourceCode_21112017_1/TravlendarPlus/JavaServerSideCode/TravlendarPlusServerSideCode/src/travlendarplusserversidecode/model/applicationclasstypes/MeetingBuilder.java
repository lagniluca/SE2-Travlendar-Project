/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travlendarplusserversidecode.model.applicationclasstypes;

import java.util.Date;

/**
 *
 * @author Chiara Campagnoli
 */
public class MeetingBuilder {
    private Date startingTime;
    
    public MeetingBuilder(final Date startingTime) {
    this.setStartingTime(startingTime);
    }
    
    private void setStartingTime(final Date startingTime) {this.startingTime = startingTime;}
    
    //public Meeting build()
    // public Boolean check()
}
